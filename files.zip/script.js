const io = new IntersectionObserver(entries => {
  entries.forEach(e => { if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target)} });
},{threshold:0.1});
document.querySelectorAll('.reveal').forEach(el=>io.observe(el));

const hdr = document.getElementById('header');
window.addEventListener('scroll',()=>{
  hdr.style.background = window.scrollY>60 ? 'rgba(8,14,26,.98)' : 'rgba(8,14,26,.92)';
});
